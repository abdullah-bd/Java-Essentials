package com.spark.fifatournament;

import android.os.AsyncTask;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class FetchData extends AsyncTask<Void,Void,Void> {
	String data="";
	String view;
	
	HashMap<Integer, String> hmap = new HashMap<>();
	Map<Integer, String> sortedMap;
	@Override
	protected Void doInBackground(Void... voids) {
		try {
			URL url = new URL("https://api.myjson.com/bins/c47la");
			HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
			InputStream inputStream = httpURLConnection.getInputStream();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			String line = "";
			while (line != null) {
				line = bufferedReader.readLine();
				data += line;
			}
			
			
			for(int i=1;i<=8;i++) {
				JSONObject JO = new JSONObject(data);
				JSONObject individual = (JSONObject) JO.get(""+i);
				//System.out.println("ab individual "+individual.getString("name")+individual.getString("score"));
				hmap.put(Integer.parseInt(individual.getString("score")),individual.getString("name"));
			}
			
			sortedMap = new TreeMap<>(hmap);
			//sorting
			Set set2 = sortedMap.entrySet();
			Iterator iterator2 = set2.iterator();
			String [] players=new String[8];
			int i=0;
			while(iterator2.hasNext()) {
				Map.Entry me2 = (Map.Entry)iterator2.next();
				System.out.print("ab debug "+me2.getKey() + ": ");
				System.out.println(me2.getValue());
				players[i++]=(String) me2.getValue();
			}
			i=0;
			view="Match \t\t Team A \t\t Team B \n";
			int left=0;
			int righ=7;
			
			while(left<=righ){
				System.out.println("ab"+left+"+"+righ);
				view+="Match-"+(++i)+"\t\t"+players[righ--]+"\t\t"+players[left++]+"\n";
			}
			
			view+="\n\n The Winner Might be "+players[players.length-1];
			
		}catch (Exception e){
			System.out.println("ab err in FetchData "+e);
		}
		
		
		
		
		return null;
	}
	
	@Override
	protected void onPostExecute(Void aVoid) {
		super.onPostExecute(aVoid);
		MainActivity.matchV.setText(view);
	}
}
